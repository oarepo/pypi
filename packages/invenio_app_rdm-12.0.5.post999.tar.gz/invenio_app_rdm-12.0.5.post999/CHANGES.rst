..
    Copyright (C) 2019-2024 CERN.
    Copyright (C) 2019-2021 Northwestern University.
    Copyright (C)      2021 TU Wien.
    Copyright (C)      2021 Graz University of Technology.

    Invenio App RDM is free software; you can redistribute it and/or modify
    it under the terms of the MIT License; see LICENSE file for more details.

Changes
=======

Version 10.0.0 (released 2022-10-10)

Version 7.0.0 (released 2021-12-06)
