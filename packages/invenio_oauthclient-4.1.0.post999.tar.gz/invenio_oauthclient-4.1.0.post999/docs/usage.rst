..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Usage
=====

GitHub
------

.. automodule:: invenio_oauthclient.contrib.github

ORCID
-----

.. automodule:: invenio_oauthclient.contrib.orcid

CERN
----

.. automodule:: invenio_oauthclient.contrib.cern

Globus
------

.. automodule:: invenio_oauthclient.contrib.globus

Keycloak
--------

.. automodule:: invenio_oauthclient.contrib.keycloak

Advanced
--------

.. automodule:: invenio_oauthclient
