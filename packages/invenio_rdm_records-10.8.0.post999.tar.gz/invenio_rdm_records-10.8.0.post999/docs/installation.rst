..
    Copyright (C) 2019 CERN.
    Copyright (C) 2019 Northwestern University.

    Invenio-DatacRDM-Recordsite is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.


.. include:: ../INSTALL.rst
