..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Example applications
====================

GitHub
------

.. include:: ../examples/github_app.py
   :start-after: SPHINX-START
   :end-before: SPHINX-END

ORCID
-----

.. include:: ../examples/orcid_app.py
   :start-after: SPHINX-START
   :end-before: SPHINX-END

Globus
------

.. include:: ../examples/globus_app.py
   :start-after: SPHINX-START
   :end-before: SPHINX-END
