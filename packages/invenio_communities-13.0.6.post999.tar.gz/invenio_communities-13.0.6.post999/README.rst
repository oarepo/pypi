..
    This file is part of Invenio.
    Copyright (C) 2016-2021 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.


=====================
 Invenio-Communities
=====================

.. image:: https://github.com/inveniosoftware/invenio-communities/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-communities/actions?query=workflow%3ACI+branch%3Amaster

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-communities.svg
        :target: https://github.com/inveniosoftware/invenio-communities/releases

.. image:: https://img.shields.io/pypi/dm/invenio-communities.svg
        :target: https://pypi.python.org/pypi/invenio-communities

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-communities.svg
        :target: https://github.com/inveniosoftware/invenio-communities/blob/master/LICENSE


Invenio module that adds support for communities.

*This is an experimental developer preview release.*

* Free software: MIT license
* Documentation: https://invenio-communities.readthedocs.io/
