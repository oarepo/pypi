License
=======

.. include:: ../LICENSE

.. note::
    In applying this license, CERN does not waive the privileges and immunities
    granted to it by virtue of its status as an Intergovernmental Organization or
    submit itself to any jurisdiction.
