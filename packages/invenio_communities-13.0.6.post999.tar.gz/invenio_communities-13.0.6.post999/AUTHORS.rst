..
    This file is part of Invenio.
    Copyright (C) 2016-2021 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.


Authors
=======

Invenio module that adds support for communities.

- Adrian Pawel Baran <adrian.pawel.baran@cern.ch>
- Eirini Psallida <eirini.psallida@cern.ch>
- Grzegorz Szpura <grzegorz.szpura@cern.ch>
- Jiri Kuncar <jiri.kuncar@cern.ch>
- Kamil Neczaj <kamil.neczaj@cern.ch>
- Krzysztof Nowak <k.nowak@cern.ch>
- Lars Holm Nielsen <lars.holm.nielsen@cern.ch>
- Leonardo Rossi <leonardo.r@cern.ch>
- Marco Neumann <marco@crepererum.net>
- Sami Hiltunen <sami.mikael.hiltunen@cern.ch>
- Tibor Simko <tibor.simko@cern.ch>
- Yoan Blanc <yoan.blanc@cern.ch>
- CERN <info@inveniosoftware.org>
- KTH Royal Institute of Technology <info@kth.se>
